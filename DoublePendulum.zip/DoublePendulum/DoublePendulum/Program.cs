﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SFML.Window;
using SFML.Audio;
using SFML.Graphics;
using SFML.System;

namespace DoublePendulum {

    class DoublePendulum {

        // radios
        private float r1 = 200;
        private float r2 = 200;

        // messes
        private float m1 = 40;
        private float m2 = 40;

        // angles
        private float a1 = MathF.PI / 2f;
        private float a2 = MathF.PI / 2f;
        
        public float a1_v = 0;
        public float a2_v = 0;
        private float a1_a = 0;
        private float a2_a = 0;

        // end pos of the first line
        private float x1;
        private float y1;

        private float x2;
        private float y2;

        private float g = 8f;

        // line
        public Vertex[] line1 = new Vertex[2];
        public Vertex[] line2 = new Vertex[2];
        
        public bool redefine = false;

        // window
        public Color lineColor;

        public DoublePendulum(Color color) {
            lineColor = color;

            // first pos of line and its color
            for (int i = 0; i < line1.Length; i++) {
                line1[i].Color = lineColor;
                line2[i].Color = lineColor;
            }
        }

        private void Calculate() {
            float num1 = -g * (2 * m1 + m2) * MathF.Sin(a1);
            float num2 = -m2 * g * MathF.Sin(a1 - 2 * a2);
            float num3 = -2 * MathF.Sin(a1 - a2);
            float num4 = m2 * ((a2_v - a2_v) * r2 + (a1_v * a1_v) * r1 * MathF.Cos(a1 - a2));
            float num = num1 + num2 + (num3 * num4);
            float den = r1 * (2 * m1 + m2 - m2 * MathF.Cos(2 * a1 - 2 * a2));
            a1_a = num / den;

            num1 = 2 * MathF.Sin(a1 - a2);
            num2 = (a1_v * a1_v) * r1 * (m1 + m2) + g * (m1 + m2) * MathF.Cos(a1); ;
            num3 = g * (m1 + m2) * MathF.Cos(a1);
            num4 = a2_v * a2_v * r2 * m2 * MathF.Cos(a1 - a2);
            den = r2 * (2 * m1 + m2 - m2 * MathF.Cos(2 * a1 - 2 * a2));
            a2_a = (num1 * (num2 + num3 + num4)) / den;

            if (float.IsNaN(a1_a) || float.IsNaN(a2_a))
                redefine = true;
        }

        public void Set() {
            Calculate();

            // set end pos line 1
            x1 = r1 * MathF.Sin(a1) + line1[0].Position.X;
            y1 = r1 * MathF.Cos(a1) + line1[0].Position.Y;

            // set end pos line 2
            x2 = x1 + r2 * MathF.Sin(a2);
            y2 = y1 + r2 * MathF.Cos(a2);

            a1_v += a1_a;
            a2_v += a2_a;
            a1 += a1_v;
            a2 += a2_v;

            // set positions
            line1[1].Position = new Vector2f(x1, y1);

            line2[0].Position = new Vector2f(x1, y1);
            line2[1].Position = new Vector2f(x2, y2);
        }
    }

    class DoublePendulumMain {

        // sizes
        private uint width = 1000;
        private uint height = 700;
        
        private static int startR = 10;
        private static int endR = 255;
        private static int startG = 10;
        private static int endG = 255;
        private static int startB = 0;
        private static int endB = 255;

        private bool draw = false;

        private static int sepR = 3;
        private static int sepG = 3;
        private static int sepB = 3;

        private float num1 = 0.000001f;
        private float num2 = 0.000001f;

        // window and videoMode
        VideoMode videoMode;
        RenderWindow window;
        Color BackgroundColor = new Color(0, 0, 0);

        DoublePendulum[] doublePendulums = new DoublePendulum[(int)(((endR - startR) / sepR)) * (int)(((endG - startG) / sepG)) * (int)(((endB - startB) / sepB))];

        public DoublePendulumMain() {

            videoMode = new VideoMode(width, height);
            window = new RenderWindow(videoMode, "Double Pendulum", Styles.Fullscreen);
            window.SetFramerateLimit(60);
            int index = 0;
            for (int r = startR; r < endR; r+=sepR)
                for (int g = startG; g < endG; g+=sepG)
                    for (int b = startB; b < endB; b+=sepB) {
                        DoublePendulum d = new DoublePendulum(new Color((byte)r, (byte)g, (byte)b));

                        d.line1[0].Position.X = window.Size.X / 2;
                        d.line1[0].Position.Y = window.Size.Y / 2;

                        d.a1_v = SelectV(index, num1);
                        d.a2_v = SelectV(r, g, b, num2);

                        try {
                            doublePendulums[index] = d;
                            index++;
                        } catch { break; }
                    }
        }

        private float SelectV(int r, int g, int b, float num) {
            return (r / g * b + r) * num;
        }

        private float SelectV(int index, float num) {
            return index * num;
        }

        #region  Events
        private void OnKeyPressed(object sender, SFML.Window.KeyEventArgs e) {
            if (e.Code == Keyboard.Key.Escape) {

                RenderWindow window = (RenderWindow)sender;
                window.Closed += Window_Closed; ; // close window
            } else if (e.Code == Keyboard.Key.Enter)
                draw = true;
        }

        private void OnClose(object sender, EventArgs e) {
            // Close the window when OnClose event is received
            RenderWindow window = (RenderWindow)sender;
            window.Closed += Window_Closed;
        }
        #endregion

        private void Event() {
            window.Closed += new EventHandler(OnClose);  // set closing event
            window.KeyPressed += OnKeyPressed;  // set key press event
        }

        public void Run() {
            Event();

            while (window.IsOpen) {
                window.DispatchEvents();

                Draw();
            }
        }

        private void Draw() {
            window.Clear(BackgroundColor);  // clear window

            if (draw) {
                for (int i = 0; i < doublePendulums.Length; i++) {
                    doublePendulums[i].Set();
                    window.Draw(doublePendulums[i].line1, PrimitiveType.Lines);
                    window.Draw(doublePendulums[i].line2, PrimitiveType.Lines);

                    if (doublePendulums[i].redefine) {
                        DoublePendulum d = new DoublePendulum(doublePendulums[i].lineColor);

                        d.a1_v = SelectV(i, num1);
                        d.a2_v = SelectV(d.lineColor.R, d.lineColor.G, d.lineColor.B, num2);

                        d.line1[0].Position.X = window.Size.X / 2;
                        d.line1[0].Position.Y = window.Size.Y / 2;
                        doublePendulums[i] = d;
                    }

                }
            }
            // refresh window
            window.Display();
        }

        void Window_Closed(object sender, EventArgs e) {
            window.Close();
        }
    }

    class Program {

        static void Main(string[] args) {
            DoublePendulumMain doublePendulum = new DoublePendulumMain();
            doublePendulum.Run();
        }
    }
} 
